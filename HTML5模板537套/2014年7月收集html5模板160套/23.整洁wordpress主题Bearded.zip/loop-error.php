	<article id="post-0" class="<?php hybrid_entry_class(); ?>">

		<header class="entry-header">
			<h1 class="entry-title"><?php __( 'Nothing found', 'bearded' ); ?></h1>
		</header>

		<div class="entry-content">
			<p><?php _e( 'Apologies, but no entries were found.', 'bearded' ); ?></p>
		</div><!-- .entry-content -->

	</article><!-- .hentry .error -->